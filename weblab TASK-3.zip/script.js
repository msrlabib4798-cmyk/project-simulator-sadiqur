function showMemberCard(name, age, email, phn, mem) {
  const sections = ["A", "B", "C"];
  const category = Number(age) < 13 ? "Junior" : "Regular";

  let fee;
  if (mem === "Basic") {
    fee = 500;
  } else if (mem === "Silver") {
    fee = 1000;
  } else {
    fee = 1500;
  }

  document.getElementById("output").innerHTML =
    "<h2>Members Information</h2>" +
    "Name: " + name + "<br>" +
    "Age: " + age + "<br>" +
    "Email: " + email + "<br>" +
    "Phone: " + phn + "<br>" +
    "Membership: " + mem + "<br>" +
    "Category: " + category + "<br>" +
    "Applicable Fee: " + fee + "<br><br>" +
    "Sections:<br>" + sections.join("<br>");
}

document.getElementById("memberForm").addEventListener("submit", function (event) {
  event.preventDefault();

  const name = document.getElementById("name").value.trim();
  const age = document.getElementById("age").value;
  const email = document.getElementById("email").value.trim();
  const phn = document.getElementById("phn").value.trim();
  const selectedMembership = document.querySelector('input[name="mem"]:checked');

  if (!selectedMembership) {
    alert("Please select a membership.");
    return;
  }

  showMemberCard(name, age, email, phn, selectedMembership.value);
});
