
function enableButton(){

	let fit = document.getElementById("fit").checked;

	if(fit == true){
		document.getElementById("join").disabled = false;
	}
	else{
		document.getElementById("join").disabled = true;
	}
}


function validateForm(){

	let name = document.getElementById("name").value;
	let age = document.getElementById("age").value;
	let mobile = document.getElementById("mobile").value;
	let email = document.getElementById("email").value;
	let password = document.getElementById("password").value;
	let confirm = document.getElementById("confirm").value;

	let plan = document.getElementById("plan").value;
	let date = document.getElementById("date").value;
	let main = document.getElementById("main").value;
	let backup = document.getElementById("backup").value;
	let addons = document.getElementById("addons").value;

	let valid = true;


	// Full Name Validation

	let nameError = "";

	if(name.length == 0){
		nameError = "Your full name is missing.";
	}
	else if(name.length < 3){
		nameError = "Full name is too short (minimum 3 letters).";
	}
	else{

		for(let i=0; i<name.length; i++){

			let ch = name.charAt(i);

			if(!((ch >= "A" && ch <= "Z") ||
			   (ch >= "a" && ch <= "z") || ch == " ")){

				nameError = "Digits and symbols are not allowed in the full name.";
				break;
			}
		}
	}

	document.getElementById("nameError").innerHTML = nameError;

	if(nameError != ""){
		valid = false;
	}


	// Age Validation

	let ageError = "";

	if(age == "" || isNaN(age) || age < 16 || age > 65){
		ageError = "Age must be a number from 16 to 65.";
	}

	document.getElementById("ageError").innerHTML = ageError;

	if(ageError != ""){
		valid = false;
	}


	// Mobile Number Validation

	let mobileError = "";

	if(mobile.length != 11 ||
	   mobile.charAt(0) != "0" ||
	   mobile.charAt(1) != "1" ||
	   mobile.charAt(2) < "3" ||
	   mobile.charAt(2) > "9"){

		mobileError = "Enter a valid mobile number (11 digits, starting with 013 to 019).";
	}
	else{

		for(let i=0; i<mobile.length; i++){

			if(mobile.charAt(i) < "0" || mobile.charAt(i) > "9"){

				mobileError = "Enter a valid mobile number (11 digits, starting with 013 to 019).";
				break;
			}
		}
	}

	document.getElementById("mobileError").innerHTML = mobileError;

	if(mobileError != ""){
		valid = false;
	}


	// Email Validation

	let emailError = "";
	let at = email.indexOf("@");

	if(email == ""){
		emailError = "Email cannot be left empty.";
	}
	else if(email.indexOf(" ") != -1 ||
	        at == -1 ||
	        at == 0 ||
	        email.indexOf(".",at) == -1){

		emailError = "This email does not look right.";
	}

	document.getElementById("emailError").innerHTML = emailError;

	if(emailError != ""){
		valid = false;
	}


	// Password Validation

	let passwordError = "";
	let capital = false;
	let digit = false;

	if(password.length < 8){
		passwordError = "Use a password of 8 or more characters.";
	}
	else{

		for(let i=0; i<password.length; i++){

			let ch = password.charAt(i);

			if(ch >= "A" && ch <= "Z"){
				capital = true;
			}

			if(ch >= "0" && ch <= "9"){
				digit = true;
			}
		}

		if(capital == false || digit == false){
			passwordError = "Password needs at least one capital letter and one digit.";
		}
	}

	document.getElementById("passwordError").innerHTML = passwordError;

	if(passwordError != ""){
		valid = false;
	}


	// Confirm Password Validation

	let confirmError = "";

	if(password != confirm){
		confirmError = "The two passwords are not the same.";
	}

	document.getElementById("confirmError").innerHTML = confirmError;

	if(confirmError != ""){
		valid = false;
	}


	// Plan Validation

	let planError = "";

	if(plan == ""){
		planError = "Please choose a plan.";
	}

	document.getElementById("planError").innerHTML = planError;

	if(planError != ""){
		valid = false;
	}


	// Main Trainer Validation

	let mainError = "";

	if(main == ""){
		mainError = "Please choose a main trainer.";
	}

	document.getElementById("mainError").innerHTML = mainError;

	if(mainError != ""){
		valid = false;
	}


	// Backup Trainer Validation

	let backupError = "";

	if(backup == ""){
		backupError = "Please choose a backup trainer.";
	}
	else if(main == backup){
		backupError = "Backup trainer must be different from the main trainer.";
	}

	document.getElementById("backupError").innerHTML = backupError;

	if(backupError != ""){
		valid = false;
	}


	// Start Date Validation

	let dateError = "";

	if(date == ""){
		dateError = "Please pick a start date.";
	}

	document.getElementById("dateError").innerHTML = dateError;

	if(dateError != ""){
		valid = false;
	}


	// Workout Time Validation

	let time = document.querySelector('input[name="time"]:checked');

	let timeError = "";

	if(time == null){
		timeError = "Please choose a workout time.";
	}

	document.getElementById("timeError").innerHTML = timeError;

	if(timeError != ""){
		valid = false;
	}


	// Family Add-ons Validation

	let addonsError = "";

	if(addons == "" || isNaN(addons) || addons < 0 || addons > 3 ||
	   addons.indexOf(".") != -1){

		addonsError = "Add-ons must be a whole number from 0 to 3.";
	}
	else{

		for(let i=0; i<addons.length; i++){

			if(addons.charAt(i) < "0" || addons.charAt(i) > "9"){

				addonsError = "Add-ons must be a whole number from 0 to 3.";
				break;
			}
		}
	}

	document.getElementById("addonsError").innerHTML = addonsError;

	if(addonsError != ""){
		valid = false;
	}


	// Check All Validation

	if(valid == false){

		document.getElementById("output").innerHTML = "";

		return false;
	}


	// Calculate Fee

	let fee;

	if(plan == "Monthly"){
		fee = 1500;
	}
	else if(plan == "Quarterly"){
		fee = 4000;
	}
	else{
		fee = 14000;
	}

	let total = fee + (addons * 500);


	// Final Message

	document.getElementById("output").innerHTML =
	"Welcome, "+name+"! Your "+plan+
	" membership starts on "+date+
	". Total payable: "+total+" Taka.";


	// Clear All Input

	document.getElementById("name").value = "";
	document.getElementById("age").value = "";
	document.getElementById("mobile").value = "";
	document.getElementById("email").value = "";
	document.getElementById("password").value = "";
	document.getElementById("confirm").value = "";

	document.getElementById("plan").selectedIndex = 0;
	document.getElementById("main").selectedIndex = 0;
	document.getElementById("backup").selectedIndex = 0;

	document.getElementById("date").value = "";
	document.getElementById("addons").value = "";

	let radio = document.querySelectorAll('input[name="time"]');

	for(let i=0; i<radio.length; i++){
		radio[i].checked = false;
	}

	document.getElementById("fit").checked = false;
	document.getElementById("join").disabled = true;

	return false;

}
